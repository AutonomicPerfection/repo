def startkinect():
  i01.startOpenNI()