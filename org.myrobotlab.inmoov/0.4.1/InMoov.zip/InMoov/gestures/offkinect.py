def offkinect():
  openni.stopCapture()
  i01.copyGesture(False)
  rest()


