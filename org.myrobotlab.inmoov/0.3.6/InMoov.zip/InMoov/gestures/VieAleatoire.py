def VieAleatoire():
  MoveRandomTimer.startClock()
  
  

  