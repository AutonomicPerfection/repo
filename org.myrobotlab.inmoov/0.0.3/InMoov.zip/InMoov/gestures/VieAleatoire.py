def VieAleatoire():
  i01.RobotCanMoveEyesRandom=1
  i01.RobotCanMoveHeadRandom=1
  
  

  