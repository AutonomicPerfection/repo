These tools converts your aiml to csv and vice versa for easy edition into Word or OpenOffice.
It uses the aiml indentation and language to organize your file.

1-Put the Ab.jar file in your ProgramAB/lib directory.

2-Put the top10K.csv in your ProgramAB/data directory.

3-Put the aiml2csv.bat in your ProgramAB directory.

4-Put the csv2aiml.bat in your ProgramAB directory
