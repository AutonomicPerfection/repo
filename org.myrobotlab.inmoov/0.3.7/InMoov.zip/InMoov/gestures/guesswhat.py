def guesswhat():
  i01.mouth.speak("I'm not really a human man")
  i01.mouth.speak("but I use Old spice body wash and deodorant together")
  i01.mouth.speak("and now I'm really cool")


