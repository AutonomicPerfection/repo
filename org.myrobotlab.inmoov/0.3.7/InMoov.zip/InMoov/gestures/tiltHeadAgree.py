def tiltHeadAgree():
  i01.disableRobotCanMoveHeadRandom(15)
  i01.setHeadVelocity(60, 60, 70)
  i01.moveHead(80,90,180)
  sleep(0.8)
  i01.moveHead(90,90,90)
