def headfront():
  i01.head.neck.moveTo(90)
  i01.head.rothead.moveTo(90)

