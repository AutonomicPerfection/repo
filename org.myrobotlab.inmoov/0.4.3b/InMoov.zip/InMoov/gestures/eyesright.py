def eyesright():
  i01.head.eyeX.moveTo(0)

