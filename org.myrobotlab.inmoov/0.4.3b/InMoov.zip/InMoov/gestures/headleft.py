def headleft():
  i01.head.rothead.moveTo(180)

