def startkinect():
  i01.copyGesture(True)


