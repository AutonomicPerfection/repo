def sorryiforgot():
  x = (random.randint(1, 2))
  if x == 1:
    i01.mouth.speak("that's alright")
  if x == 2:
    i01.mouth.speak("you forget all the time")
