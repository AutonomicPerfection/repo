def VieAleatoireStop():
  i01.RobotCanMoveEyesRandom=0
  i01.RobotCanMoveHeadRandom=0

  