def fighter():
  i01.moveHead(160,87)
  i01.moveArm("left",31,75,152,10)
  i01.moveArm("right",3,94,33,16)
  i01.moveHand("left",161,151,133,127,107,83)
  i01.moveHand("right",99,130,152,154,145,180)
  i01.moveTorso(90,90,90)