Empty white script page, full of your imagination
