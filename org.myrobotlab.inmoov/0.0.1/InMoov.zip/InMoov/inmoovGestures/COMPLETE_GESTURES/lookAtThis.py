def lookAtThis():
  i01.moveHead(66,79)
  i01.moveArm("left",89,75,78,19)
  i01.moveArm("right",90,91,72,26)
  i01.moveHand("left",92,106,133,127,107,29)
  i01.moveHand("right",86,51,133,162,153,180)
  i01.moveTorso(90,90,90)