def cyclegesture1():
  welcome()
  sleep(1)
  relax()
  servos()

