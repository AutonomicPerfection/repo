def armsFront():
  i01.moveHead(99,82)
  i01.moveArm("left",9,115,96,51)
  i01.moveArm("right",13,104,101,49)
  i01.moveHand("left",61,0,14,38,15,0)
  i01.moveHand("right",0,24,54,50,82,180)
  i01.moveTorso(90,90,90)