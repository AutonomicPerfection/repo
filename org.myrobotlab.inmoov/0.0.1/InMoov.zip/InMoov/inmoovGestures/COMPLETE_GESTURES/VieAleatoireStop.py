def VieAleatoireStop():
  MoveHeadTimer.stopClock()
  global MoveHeadRandom
  MoveHeadRandom=0
  MoveBodyTimer.stopClock()
  global MoveBodyRandom
  MoveBodyRandom=0

  