def stopTracking():
  i01.headTracking.stopTracking()
  i01.eyesTracking.stopTracking()

