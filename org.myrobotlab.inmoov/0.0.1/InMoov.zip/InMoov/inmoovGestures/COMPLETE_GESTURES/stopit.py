def stopit():
  lookinmiddle()
  sleep(1)
  relax()
  i01.mouth.speak("yes")
  if (data == "pause"):
    i01.mouth.speak("yes")

