def VieAleatoire():
  global MoveBodyRandom
  global MoveHeadRandom
  MoveBodyRandomize()
  MoveHeadRandomize()
  MoveHeadTimer.startClock()
  MoveBodyTimer.startClock()
  MoveBodyRandom=1
  MoveHeadRandom=1

  