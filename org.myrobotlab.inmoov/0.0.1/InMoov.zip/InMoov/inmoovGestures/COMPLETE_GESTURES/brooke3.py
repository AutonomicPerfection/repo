def brooke3():
  i01.enable()
  fullspeed()
  gestureforlondon4()
  sleep(2)
  i01.disable()
  sleep(30)
  brooke4() 
