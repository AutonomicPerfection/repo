def eyesup():
  i01.head.eyeY.moveTo(0)

