def brooke2():
  i01.enable()
  fullspeed()
  gestureforlondon3()
  sleep(2)
  i01.disable()
  sleep(30)
  brooke3()
