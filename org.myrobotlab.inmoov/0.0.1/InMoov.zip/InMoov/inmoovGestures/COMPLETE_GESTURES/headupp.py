def headupp():
  i01.head.neck.moveTo(180)

