def detachAll():
  i01.disable()