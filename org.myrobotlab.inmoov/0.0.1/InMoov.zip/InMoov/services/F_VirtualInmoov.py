# ##############################################################################
#                 VIRTUAL INMOOV SERVICE
# ##############################################################################

if ScriptType=="Virtual":talkEvent(lang_startingVirtual)

#virtual inmoov
#i01.VinmoovFullScreen=0
#i01.VinmoovBackGroundColor="Grey"
#i01.VinmoovWidth=800
